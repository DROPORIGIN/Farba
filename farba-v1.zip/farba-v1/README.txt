FARBA V1 – lokaler UI/Regel-Prototyp

Start: index.html im Browser öffnen.
Enthalten: Nickname/Raumcode, Lobby, Coin-Guthaben, Tische mit Mindestbestand, Admin-Demo-Aufladung, FARBA-Tisch, 32-Karten-Deck, Handwertung für Farbpunkte/Drilling/Vierling und erste Aktionsoberfläche.

Noch nicht enthalten: echtes Online-Multiplayer, persistente Accounts/Datenbank, vollständige Betting-State-Machine, Kartentausch-Synchronisation, Carry-Pot/Nachzahlungen und serverseitige Admin-Rechte. Diese Funktionen benötigen Backend + Echtzeitserver.

Coins sind ausschließlich virtuelle Spielchips ohne Geldwert oder Auszahlung.
